from abaqus import *
from abaqusConstants import *
from part import *
from assembly import *
from mesh import *

def editMaterials(modelName_fiber, modelName_matrix, materialName_fiber, materialName_matrix):

    mdb.models[modelName_fiber].HomogeneousSolidSection(material=materialName_fiber, name=
        'Section-Fiber', thickness=None)
    mdb.models[modelName_fiber].parts['Part-1'].SectionAssignment(offset=0.0, 
        offsetField='', offsetType=MIDDLE_SURFACE, region=
        mdb.models[modelName_fiber].parts['Part-1'].sets['Set-Fiber'], sectionName=
        'Section-Fiber', thicknessAssignment=FROM_SECTION)
    # #
    mdb.models[modelName_matrix].HomogeneousSolidSection(material=materialName_matrix, name=
        'Section-Matrix', thickness=None)
    mdb.models[modelName_matrix].parts['Part-1'].SectionAssignment(offset=0.0, 
        offsetField='', offsetType=MIDDLE_SURFACE, region=
        mdb.models[modelName_matrix].parts['Part-1'].sets['Set-Matrix'], sectionName=
        'Section-Matrix', thicknessAssignment=FROM_SECTION)