from abaqusGui import getAFXApp, Activator, AFXMode, afxCreatePNGIcon
from abaqusConstants import ALL
import os
thisPath = os.path.abspath(__file__)
thisDir = os.path.dirname(thisPath)

toolset = getAFXApp().getAFXMainWindow().getPluginToolset()
toolset.registerGuiMenuButton(
    buttonText='Viscoelastic RVE Calculator|Generate PBC and Calculate', 
    object=Activator(os.path.join(thisDir, 'easyPBCDB.py')),
    kernelInitString='import easypbc',
    messageId=AFXMode.ID_ACTIVATE,
    icon=None,
    applicableModules=ALL,
    version='1.0',
    author='created by Sadik Omairey, modified by Ning An',
    description='N/A',
    helpUrl='N/A'
)
