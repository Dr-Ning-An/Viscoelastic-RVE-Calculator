from abaqus import *
from abaqusConstants import *
from part import *
from assembly import *
from mesh import *

def createRVE(model_lib_item, partName, fiber_vof, RVE_length, Edge_seeds):

    ##################################################################################
    #Parameters
    vof = fiber_vof
    l = RVE_length
    ##################################################################################
    
    # Mdb()
    
    if model_lib_item=='Square Array':

        r = (l*l*vof/pi)**0.5

        modelName = 'RVE_Square'
        mdb.Model(modelType=STANDARD_EXPLICIT, name=modelName)

        mdb.models[modelName].ConstrainedSketch(name='__profile__', sheetSize=1.0)
        mdb.models[modelName].sketches['__profile__'].rectangle(point1=(0.0, 0.0), 
            point2=(l/2.0, l/2.0))
        mdb.models[modelName].Part(dimensionality=THREE_D, name=partName + '-A', type=
            DEFORMABLE_BODY)
        mdb.models[modelName].parts[partName + '-A'].BaseSolidExtrude(depth=l/2.0, sketch=
            mdb.models[modelName].sketches['__profile__'])
        del mdb.models[modelName].sketches['__profile__']
        
        
        mdb.models[modelName].ConstrainedSketch(gridSpacing=0.03, name='__profile__', 
            sheetSize=1.41, transform=
            mdb.models[modelName].parts[partName + '-A'].MakeSketchTransform(
            sketchPlane=mdb.models[modelName].parts[partName + '-A'].faces.findAt((0.0, 
            l/4.0, l/4.0), ), sketchPlaneSide=SIDE1, 
            sketchUpEdge=mdb.models[modelName].parts[partName + '-A'].edges.findAt((0.0, 
            l/4.0, l/2.0), ), sketchOrientation=RIGHT, origin=(0.0, 0.0, 0.0)))
        mdb.models[modelName].parts[partName + '-A'].projectReferencesOntoSketch(filter=
            COPLANAR_EDGES, sketch=mdb.models[modelName].sketches['__profile__'])
        mdb.models[modelName].sketches['__profile__'].ArcByCenterEnds(center=(0.0, 
            0.0), direction=CLOCKWISE, point1=(0.0, r), point2=(r, 
            0.0))
        mdb.models[modelName].sketches['__profile__'].Line(point1=(0.0, 0.0), 
            point2=(0.0, r))
        mdb.models[modelName].sketches['__profile__'].Line(point1=(0.0, 0.0), 
            point2=(r, 0.0))
        
        mdb.models[modelName].parts[partName + '-A'].SolidExtrude(depth=l/2.0, 
            flipExtrudeDirection=ON, keepInternalBoundaries=ON, sketch=
            mdb.models[modelName].sketches['__profile__'], sketchOrientation=RIGHT, 
            sketchPlane=mdb.models[modelName].parts[partName + '-A'].faces.findAt((0.0, 
            l/4.0, l/4.0), ), sketchPlaneSide=SIDE1, sketchUpEdge=
            mdb.models[modelName].parts[partName + '-A'].edges.findAt((0.0, l/4.0, l/2.0), ))
        del mdb.models[modelName].sketches['__profile__']
        
        mdb.models[modelName].parts[partName + '-A'].Set(cells=
            mdb.models[modelName].parts[partName + '-A'].cells.findAt(((0.0, 0.0, 
            0.0), )), name='Set-Fiber')
        mdb.models[modelName].parts[partName + '-A'].Set(cells=
            mdb.models[modelName].parts[partName + '-A'].cells.findAt(((0.0, l/2.0, 
            l/2.0), )), name='Set-Matrix')
        

    if model_lib_item=='Diamond Array':

        r = (l*l*vof/2.0/pi)**0.5

        modelName = 'RVE_Diamond'
        mdb.Model(modelType=STANDARD_EXPLICIT, name=modelName)

        mdb.models[modelName].ConstrainedSketch(name='__profile__', sheetSize=1.0)
        mdb.models[modelName].sketches['__profile__'].rectangle(point1=(0.0, 0.0), 
            point2=(l/2.0, l/2.0))
        mdb.models[modelName].Part(dimensionality=THREE_D, name=partName + '-A', type=
            DEFORMABLE_BODY)
        mdb.models[modelName].parts[partName + '-A'].BaseSolidExtrude(depth=l/2.0, sketch=
            mdb.models[modelName].sketches['__profile__'])
        del mdb.models[modelName].sketches['__profile__']
        
        
        mdb.models[modelName].ConstrainedSketch(gridSpacing=0.03, name='__profile__', 
            sheetSize=1.41, transform=
            mdb.models[modelName].parts[partName + '-A'].MakeSketchTransform(
            sketchPlane=mdb.models[modelName].parts[partName + '-A'].faces.findAt((0.0, 
            l/4.0, l/4.0), ), sketchPlaneSide=SIDE1, 
            sketchUpEdge=mdb.models[modelName].parts[partName + '-A'].edges.findAt((0.0, 
            l/4.0, l/2.0), ), sketchOrientation=RIGHT, origin=(0.0, 0.0, 0.0)))
        mdb.models[modelName].parts[partName + '-A'].projectReferencesOntoSketch(filter=
            COPLANAR_EDGES, sketch=mdb.models[modelName].sketches['__profile__'])
        
        mdb.models[modelName].sketches['__profile__'].ArcByCenterEnds(center=(0.0, 
            0.0), direction=CLOCKWISE, point1=(0.0, r), point2=(r, 
            0.0))
        mdb.models[modelName].sketches['__profile__'].Line(point1=(0.0, 0.0), 
            point2=(0.0, r))
        mdb.models[modelName].sketches['__profile__'].Line(point1=(0.0, 0.0), 
            point2=(r, 0.0))
        
        mdb.models[modelName].sketches['__profile__'].ArcByCenterEnds(center=(l/2.0, 
            l/2.0), direction=CLOCKWISE, point1=(l/2.0, l/2.0-r), point2=(l/2.0-r, 
            l/2.0))
        mdb.models[modelName].sketches['__profile__'].Line(point1=(l/2.0, l/2.0), 
            point2=(l/2.0, l/2.0-r))
        mdb.models[modelName].sketches['__profile__'].Line(point1=(l/2.0, l/2.0), 
            point2=(l/2.0-r, l/2.0))
        
        mdb.models[modelName].parts[partName + '-A'].SolidExtrude(depth=l/2.0, 
            flipExtrudeDirection=ON, keepInternalBoundaries=ON, sketch=
            mdb.models[modelName].sketches['__profile__'], sketchOrientation=RIGHT, 
            sketchPlane=mdb.models[modelName].parts[partName + '-A'].faces.findAt((0.0, 
            l/4.0, l/4.0), ), sketchPlaneSide=SIDE1, sketchUpEdge=
            mdb.models[modelName].parts[partName + '-A'].edges.findAt((0.0, l/4.0, l/2.0), ))
        del mdb.models[modelName].sketches['__profile__']
        
        mdb.models[modelName].parts[partName + '-A'].Set(cells=
            mdb.models[modelName].parts[partName + '-A'].cells.findAt(((0.0, 0.0, 
            0.0), ), ((0.0, l/2.0, l/2.0), ), ), name='Set-Fiber')
        mdb.models[modelName].parts[partName + '-A'].Set(cells=
            mdb.models[modelName].parts[partName + '-A'].cells.findAt(((0.0, 0.0, 
            l/2.0), )), name='Set-Matrix')
    
    if model_lib_item=='Hexagonal Array':

        r = (sqrt(3.0)/2.0*l*l*vof/pi)**0.5

        modelName = 'RVE_Hexagonal'
        mdb.Model(modelType=STANDARD_EXPLICIT, name=modelName)

        mdb.models[modelName].ConstrainedSketch(name='__profile__', sheetSize=1.0)
        mdb.models[modelName].sketches['__profile__'].rectangle(point1=(0.0, 0.0), 
            point2=(l/2.0, l/2.0))
        mdb.models[modelName].Part(dimensionality=THREE_D, name=partName + '-A', type=
            DEFORMABLE_BODY)
        mdb.models[modelName].parts[partName + '-A'].BaseSolidExtrude(depth=sqrt(3.0)/2.0*l, sketch=
            mdb.models[modelName].sketches['__profile__'])
        del mdb.models[modelName].sketches['__profile__']
        
        
        mdb.models[modelName].ConstrainedSketch(gridSpacing=0.03, name='__profile__', 
            sheetSize=1.41, transform=
            mdb.models[modelName].parts[partName + '-A'].MakeSketchTransform(
            sketchPlane=mdb.models[modelName].parts[partName + '-A'].faces.findAt((0.0, 
            l/4.0, l/4.0), ), sketchPlaneSide=SIDE1, 
            sketchUpEdge=mdb.models[modelName].parts[partName + '-A'].edges.findAt((0.0, 
            l/4.0, sqrt(3.0)/2.0*l), ), sketchOrientation=RIGHT, origin=(0.0, 0.0, 0.0)))
        mdb.models[modelName].parts[partName + '-A'].projectReferencesOntoSketch(filter=
            COPLANAR_EDGES, sketch=mdb.models[modelName].sketches['__profile__'])
        mdb.models[modelName].sketches['__profile__'].ArcByCenterEnds(center=(0.0, 
            0.0), direction=CLOCKWISE, point1=(0.0, r), point2=(r, 
            0.0))
        mdb.models[modelName].sketches['__profile__'].Line(point1=(0.0, 0.0), 
            point2=(0.0, r))
        mdb.models[modelName].sketches['__profile__'].Line(point1=(0.0, 0.0), 
            point2=(r, 0.0))
        
        mdb.models[modelName].parts[partName + '-A'].projectReferencesOntoSketch(filter=
            COPLANAR_EDGES, sketch=mdb.models[modelName].sketches['__profile__'])
        mdb.models[modelName].sketches['__profile__'].ArcByCenterEnds(center=(sqrt(3.0)/2.0*l, 
            l/2.0), direction=CLOCKWISE, point1=(sqrt(3.0)/2.0*l, l/2.0-r), point2=(sqrt(3.0)/2.0*l-r, 
            l/2.0))
        mdb.models[modelName].sketches['__profile__'].Line(point1=(sqrt(3.0)/2.0*l, l/2.0), 
            point2=(sqrt(3.0)/2.0*l, l/2.0-r))
        mdb.models[modelName].sketches['__profile__'].Line(point1=(sqrt(3.0)/2.0*l, l/2.0), 
            point2=(sqrt(3.0)/2.0*l-r, l/2.0))
        
        mdb.models[modelName].parts[partName + '-A'].SolidExtrude(depth=l/2.0, 
            flipExtrudeDirection=ON, keepInternalBoundaries=ON, sketch=
            mdb.models[modelName].sketches['__profile__'], sketchOrientation=RIGHT, 
            sketchPlane=mdb.models[modelName].parts[partName + '-A'].faces.findAt((0.0, 
            l/4.0, l/4.0), ), sketchPlaneSide=SIDE1, sketchUpEdge=
            mdb.models[modelName].parts[partName + '-A'].edges.findAt((0.0, l/4.0, sqrt(3.0)/2.0*l), ))
        del mdb.models[modelName].sketches['__profile__']
        
        mdb.models[modelName].parts[partName + '-A'].Set(cells=
            mdb.models[modelName].parts[partName + '-A'].cells.findAt(((0.0, 0.0, 
            0.0), ), ((0.0, l/2.0, sqrt(3)/2.0*l), ), ), name='Set-Fiber')
        mdb.models[modelName].parts[partName + '-A'].Set(cells=
            mdb.models[modelName].parts[partName + '-A'].cells.findAt(((0.0, 0.0, 
            sqrt(3)/2.0*l), )), name='Set-Matrix')


    mdb.models[modelName].parts[partName + '-A'].seedPart(deviationFactor=0.1, 
        minSizeFactor=0.1, size=float(l)/float(Edge_seeds))
    mdb.models[modelName].parts[partName + '-A'].setMeshControls(elemShape=TET, regions=
        mdb.models[modelName].parts[partName + '-A'].cells, technique=FREE)
    mdb.models[modelName].parts[partName + '-A'].setElementType(elemTypes=(ElemType(
        elemCode=C3D20R, elemLibrary=STANDARD), ElemType(elemCode=C3D15, 
        elemLibrary=STANDARD), ElemType(elemCode=C3D10, elemLibrary=STANDARD)), 
        regions=(mdb.models[modelName].parts[partName + '-A'].cells, ))
    mdb.models[modelName].parts[partName + '-A'].generateMesh()
    
    
    mdb.models[modelName].parts[partName + '-A'].PartFromMesh(copySets=True, name=
        partName + '-A-Mesh')
    mdb.models[modelName].Part(compressFeatureList=ON, mirrorPlane=XYPLANE, name=
        partName + '-B-Mesh', objectToCopy=mdb.models[modelName].parts[partName + '-A-Mesh'])
    mdb.models[modelName].Part(compressFeatureList=ON, mirrorPlane=XZPLANE, name=
        partName + '-C-Mesh', objectToCopy=mdb.models[modelName].parts[partName + '-A-Mesh'])
    mdb.models[modelName].Part(compressFeatureList=ON, mirrorPlane=XZPLANE, name=
        partName + '-D-Mesh', objectToCopy=mdb.models[modelName].parts[partName + '-B-Mesh'])
    mdb.models[modelName].Part(compressFeatureList=ON, mirrorPlane=YZPLANE, name=
        partName + '-E-Mesh', objectToCopy=mdb.models[modelName].parts[partName + '-A-Mesh'])
    mdb.models[modelName].Part(compressFeatureList=ON, mirrorPlane=YZPLANE, name=
        partName + '-F-Mesh', objectToCopy=mdb.models[modelName].parts[partName + '-B-Mesh'])
    mdb.models[modelName].Part(compressFeatureList=ON, mirrorPlane=YZPLANE, name=
        partName + '-G-Mesh', objectToCopy=mdb.models[modelName].parts[partName + '-C-Mesh'])
    mdb.models[modelName].Part(compressFeatureList=ON, mirrorPlane=YZPLANE, name=
        partName + '-H-Mesh', objectToCopy=mdb.models[modelName].parts[partName + '-D-Mesh'])
    
    
    mdb.models[modelName].rootAssembly.Instance(dependent=ON, name=partName + '-A-Mesh-1', 
        part=mdb.models[modelName].parts[partName + '-A-Mesh'])
    mdb.models[modelName].rootAssembly.Instance(dependent=ON, name=partName + '-B-Mesh-1', 
        part=mdb.models[modelName].parts[partName + '-B-Mesh'])
    mdb.models[modelName].rootAssembly.Instance(dependent=ON, name=partName + '-C-Mesh-1', 
        part=mdb.models[modelName].parts[partName + '-C-Mesh'])
    mdb.models[modelName].rootAssembly.Instance(dependent=ON, name=partName + '-D-Mesh-1', 
        part=mdb.models[modelName].parts[partName + '-D-Mesh'])
    mdb.models[modelName].rootAssembly.Instance(dependent=ON, name=partName + '-E-Mesh-1', 
        part=mdb.models[modelName].parts[partName + '-E-Mesh'])
    mdb.models[modelName].rootAssembly.Instance(dependent=ON, name=partName + '-F-Mesh-1', 
        part=mdb.models[modelName].parts[partName + '-F-Mesh'])
    mdb.models[modelName].rootAssembly.Instance(dependent=ON, name=partName + '-G-Mesh-1', 
        part=mdb.models[modelName].parts[partName + '-G-Mesh'])
    mdb.models[modelName].rootAssembly.Instance(dependent=ON, name=partName + '-H-Mesh-1', 
        part=mdb.models[modelName].parts[partName + '-H-Mesh'])
    #
    mdb.models[modelName].rootAssembly.InstanceFromBooleanMerge(domain=MESH, 
        instances=(mdb.models[modelName].rootAssembly.instances[partName + '-A-Mesh-1'], 
        mdb.models[modelName].rootAssembly.instances[partName + '-B-Mesh-1'], 
        mdb.models[modelName].rootAssembly.instances[partName + '-C-Mesh-1'], 
        mdb.models[modelName].rootAssembly.instances[partName + '-D-Mesh-1'], 
        mdb.models[modelName].rootAssembly.instances[partName + '-E-Mesh-1'], 
        mdb.models[modelName].rootAssembly.instances[partName + '-F-Mesh-1'], 
        mdb.models[modelName].rootAssembly.instances[partName + '-G-Mesh-1'], 
        mdb.models[modelName].rootAssembly.instances[partName + '-H-Mesh-1']), mergeNodes=
        BOUNDARY_ONLY, name=partName, nodeMergingTolerance=1e-06, 
        originalInstances=DELETE)

    mdb.models[modelName].rootAssembly.Instance(dependent=ON, name=partName+'-1', 
        part=mdb.models[modelName].parts[partName])
    
    mdb.models[modelName].rootAssembly.regenerate()