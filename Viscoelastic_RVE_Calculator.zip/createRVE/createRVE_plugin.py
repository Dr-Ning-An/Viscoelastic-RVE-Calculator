from abaqusGui import *
from abaqusConstants import ALL
import osutils, os
thisPath = os.path.abspath(__file__)
thisDir = os.path.dirname(thisPath)

toolset = getAFXApp().getAFXMainWindow().getPluginToolset()
toolset.registerGuiMenuButton(
    buttonText='Viscoelastic RVE Calculator|Create RVE', 
    object=Activator(os.path.join(thisDir, 'createRVEDB.py')),
    kernelInitString='import createRVE',
    messageId=AFXMode.ID_ACTIVATE,
    icon=None,
    applicableModules=ALL,
    version='N/A',
    author='N/A',
    description='N/A',
    helpUrl='N/A'
)
